package fxAppeareance;

/*
 * Peter Gauld
 * Java FX Styler - A class meant to contain functions for helping to style FX components. This primarily will use FX CSS.
 * 
 * 2/14/2022 - File created.
 */

public class Styler {

}
